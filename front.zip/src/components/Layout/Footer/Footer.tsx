import "./Footer.css";

const Footer = () =>{
    return(
        <>
            <div className="footer-main">
                <p>&copy; copyrights 2022 Doge Academy | All Rights Reserved.</p>
            </div>
        </>
    );
}

export default Footer;